function [ma,mi,exp,acc]=MC_GM(X_train,Y_train,X_test,Y_test,s,lambda,delta,alpha,beta)

%s: number of groups
%X \in [0,1]
%Y \in {-1,1}


% [n,d]=size(X);
% [n,k]=size(Y);
% 
% ma=max(X);
% mi=min(X);
% 
% X=(X-repmat(mi,n,1))./(repmat(ma-mi,n,1));
% 
% max(max(X))
% min(min(X))
% 
% r = 0.2;%ratio of test data
% Label = Y;
% % Label(Label==0)=-1;
% Y = double(Label);
% X = double(X);
% [n_total, n_feat] = size(X);
% n_test = round(r*n_total);
% n_train = n_total - n_test;
% 
% nCross = 5; %here we use 5-cross-validation
% rand_sq = randperm(n_total);
% for i=1:nCross-1
%     test_sq{i} = rand_sq((i-1)*n_test+1:i*n_test);
%     temp = 1:n_total;
%     temp(test_sq{i}) = [];
%     train_sq{i} = temp;
% end
%  i = nCross;
%  test_sq{i} = rand_sq((i-1)*n_test+1:end);
%  temp = 1:n_total;
%  temp(test_sq{i}) = [];
%  train_sq{i} = temp;
%  
% X_train=X(train_sq{1},:);
% X_test=X(test_sq{1},:);
% 
% Y_train=Y(train_sq{1},:);
% Y_test=Y(test_sq{1},:);



iter=100;



addpath('evaluation');


%%% normalization
%tic;
[n_train,d]=size(X_train);
[~,k]=size(Y_train);


%%%%%%%%%% Group-specific Feature Selection
IDX = kmeans(X_train, s,'EmptyAction','singleton','OnlinePhase','off','Display','off');

A=[];
B=[];


for j=1:s
    [ix,~]=find(IDX==j);
    if length(ix)~=1
    A=[A;mean(X_train(ix,:))];
    B=[B;mean(Y_train(ix,:))]; 
    else
    A=[A;X_train(ix,:)];
    B=[B;Y_train(ix,:)];
    end
end

B=B';

 P=diag(ones(1,n_train)*(X_train.^2));
 A1=X_train'*(eye(n_train).*(Y_train*Y_train'))*ones(n_train,s);
 A2=X_train'*Y_train*Y_train'*X_train+delta*X_train'*X_train+delta*P;
 U3=pinv(2*A2);
 
 for i=1:iter
 U1=2*(1+lambda)*X_train'*Y_train*B;
 U2=lambda*(A1+X_train'*ones(n_train,s)*(eye(s).*(B'*B)));
 U=U3*(U1-U2);
 
 B1=(1+lambda)*Y_train'*X_train*U;
 B=B1*inv(eye(s)+lambda*diag(U'*X_train'*ones(n_train,1)));
 end

 

 %%%%%%%%%% inter-group correlation
 
M=affinity(Y_train);
V=affinity(Y_train');

Q=rand(s,s);
Q=(Q+Q')/s;
for j=1:s
    Q(j,j)=0;
end

 Q1=B'*B;
 Q2=U'*(X_train'*X_train)*U;

a=0;
for i=1:s
    for j=1:s
        a=a+max(reshape(Q1(:,i)*Q1(j,:),s*s,1))^2+max(reshape(Q2(:,i)*Q2(j,:),s*s,1))^2;
    end
end

L2=s*sqrt(2*a)+eps;

A1=B'*M*B;
A2=U'*X_train'*V*X_train*U;


for i=1:iter
    dQ=Q1*Q*Q1+Q2*Q*Q2-A1-A2;
    Q3=((Q-(1/L2)*dQ)+(Q-(1/L2)*dQ)')/2;
    
    b=(eye(s)/s+(2-s)/(2*s^2*(s-1))*ones(s,s))*(ones(s,1)-Q3*ones(s,1)+trace(Q3)*ones(s,1)/s);
    c=-1/s*(trace(Q3)+2*b'*ones(s,1));
    
    Q=Q3+c*eye(s)+ones(s,1)*b'+b*ones(1,s);
    Q4=(Q>=0);
    Q=Q4.*Q;
end

    

%%%%%%%%%% Label-specific Group Selection
G=0.5*eye(s)+0.5*Q;
W=rand(s,k);

B=(B-repmat(mean(B),k,1))./repmat(sqrt(sum((B-repmat(mean(B),k,1)).^2))+eps,k,1);


L3=(norm(G*Q2*G','fro'))^2+eps;

C1=G*Q2*G';
C2=G*U'*X_train'*Y_train;


for l=1:iter

O=zeros(s,k);

for i=1:s 
    d1=W(i,:).*W(i,:);
    d3=zeros(k,k);
    for j=1:s      
        d2=W(j,:).*W(j,:);
        d3=d3+G(i,j)*diag(1./(2*sqrt(sum([d1;d2])+eps)));        
    end
    O(i,:)=ones(1,k)*d3;
end

L4=sqrt(2*(L3+(beta*max(reshape(O,s*k,1)))^2));

dW=C1*W-C2-alpha*B'+beta*W.*O;
W=W-(1/L4)*dW;
end


%%%%%%%%%% prediction
Y_pre=X_test*U*G*W;

Y_test(Y_test==0)=-1;
Y_pre(find(Y_pre<0))=-1;
 Y_pre(find(Y_pre>=0))=1;

[~, ma, mi] = compute_measures(Y_test, Y_pre);

[~, exp,~] = compute_measures(Y_test', Y_pre');

Y_pre(find(Y_pre==-1))=0;
Y_test(find(Y_test==-1))=0;
[~,acc]=PerformanceMeasure(Y_test, Y_pre);


   






