% function [HammingLoss, Macro_F1, Micro_F1, Macro_Precision, Micro_Precision,  Macro_Recall, Micro_Recall, F_all, Precision_all, Recall_all] = compute_measures(Y_te, Y_pre)
% num_label = size(Y_te,2);
% num_inst = size(Y_te,1);
% 
% % compute HammingLoss
% HammingLoss = Hamming_loss(Y_te',Y_pre');
% 
% %Macro_F1
% for t = 1 : num_label
%     [F(t), TP(t), FP(t), TN(t), FN(t), Precision(t), Recall(t)] = computeF1_2(Y_te(:,t), Y_pre(:,t)); 
% end       
% Macro_F1  = mean(F);
% Macro_Precision  = mean(Precision);
% Macro_Recall  = mean(Recall);
% %Micro_F1
% [Micro_F1, Micro_Precision, Micro_Recall]= computeF1_3(sum(TP), sum(FP), sum(TN), sum(FN) );
% 
% [F_all, TP_all, FP_all, TN_all, FN_all, Precision_all, Recall_all] = computeF1_2(Y_te(:), Y_pre(:)); 

function [HammingLoss, Macro_F1, Micro_F1] = compute_measures(Y_te, Y_pre)
num_label = size(Y_te,2);
num_inst = size(Y_te,1);

% compute HammingLoss
HammingLoss = Hamming_loss(Y_te',Y_pre');

%Macro_F1
for t = 1 : num_label
    [F(t), TP(t), FP(t), TN(t), FN(t)] = computeF1_2(Y_te(:,t), Y_pre(:,t)); 
end       
Macro_F1  = mean(F);

%Micro_F1
[Micro_F1, Micro_Precision, Micro_Recall]= computeF1_3(sum(TP), sum(FP), sum(TN), sum(FN) );

